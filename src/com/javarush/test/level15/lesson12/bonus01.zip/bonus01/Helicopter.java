package com.javarush.test.level15.lesson12.bonus01;

/**
 * Created by Kira on 23.01.2016.
 */
public class Helicopter implements Flyable
{
    public void fly() {}
}
